<?php
abstract class Person
{
    private $fname, $lname,$email,$mobile;
    // constructor
    public function __construct($fname,$lname)
    {
        $this->fname = $fname;
        $this->lname = $lname;
    }
    //fname
    public function getfname()
    {
        return $this->fname;
    }
    public function setfname($value)
    {
        $this->fname = $value;
    }
    //lname
    public function getlname()
    {
        return $this->lname;
    }
    public function setlname($value)
    {
        $this->lname = $value;
    }
    //email
    public function getemail()
    {
        return $this->email;
    }
    public function setemail($value)
    {
        $this->email = $value;
    }
    //mobile
    public function getmobile()
    {
        return $this->mobile;
    }
    public function setmobile($value)
    {
        $this->mobile = $value;
    }
    // abstract method
     public function getfullname()
     {
        
     }
}
class Employee extends Person
{
    private $eid,$edept;
    //
    public function __construct($fname,$lname,$eid,$edept)
    {
        $this->eid = $eid;
        $this->edept = $edept;
        parent::__construct($fname,$lname);
    }
    //eid
    public function geteid()
    {
        return $this->eid;
    }
    public function seteid($value)
    {
        $this->eid = $value;
    }
    //edpet
    public function getedept()
    {
        return $this->edept;
    }
    public function setedept($value)
    {
        $this->edept = $value;
    }
    public function getfullname()
    {
        $fullname = $this->getfname().' '.$this->getlname();
        return $fullname;
    }
}

$e1 = new Employee('first','last',101,'IT');
print_r($e1);
echo "<br> Set Mobile number <br>";
$e1->setmobile(1234567890);
echo "<br> Display Mobile Number : ". $e1->getmobile();

?>