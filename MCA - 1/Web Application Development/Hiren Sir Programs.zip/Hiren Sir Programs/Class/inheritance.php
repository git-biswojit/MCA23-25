<?php
class Employee
{
    protected $eid, $ename;
    //
    public function __construct($eid,$ename)
    {
        $this->eid = $eid;
        $this->ename = $ename;
    }
    //eid
    public function geteid()
    {
        return $this->eid;
    }
    public function seteid($value)
    {
        $this->eid = $value;
    }
    //ename
    public function getename()
    {
        return $this->ename;
    }
    public function setename($value)
    {
        $this->ename = $value;
    }
}

class Manager extends Employee
{
    private $email, $mobile;
    //constructor
    public function __construct($eid,$ename,$email,$mobile)
    {
        $this->email = $email;
        $this->mobile = $mobile;
        parent::__construct($eid,$ename);
    }
    // email
    public function getemail()
    {
        return $this->email;
    }
    public function setemail($value)
    {
        $this->email = $value;
    }
    //mobile
    public function getmobile()
    {
        return $this->mobile;
    }
    public function setmobile($value)
    {
        $this->mobile = $value;
    }

}
//
$m1 = new Manager(1,'One','abc@xyz.com',1234567890);
echo "<br> object m1 is <br>";
print_r($m1);
$m1->setename('Ram Krishan');
echo "<br> object m1 is <br>";
print_r($m1);
$m1->setmobile(9876543210);
echo "<br> ";
//print_r($m1);

echo "<br> Mobile number is : ". $m1->getmobile();

echo "<br> check for private :". $m1->eid;

?>