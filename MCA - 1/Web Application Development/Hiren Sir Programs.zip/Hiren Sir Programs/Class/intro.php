<?php
class Employee
{
    private $eid, $ename;
    //
    public function __construct($eid,$ename)
    {
        $this->eid = $eid;
        $this->ename = $ename;
    }
    //eid
    public function geteid()
    {
        return $this->eid;
    }
    public function seteid($value)
    {
        $this->eid = $value;
    }
    //ename
    public function getename()
    {
        return $this->ename;
    }
    public function setename($value)
    {
        $this->ename = $value;
    }
}
$obj1 = new Employee('102','Vimal');
print_r($obj1);
echo "<br> check class exists <br>";
$a = class_exists('Employee');
if ($a)
{
    echo "<br> class Employee is exists";
}
else
{
    echo "<br> class Employee does not exists";
}
//
$b = property_exists('Employee','eid');
if ($b)
{
    echo "<br> property exists";
}
else
{
    echo "<br> property does not exists";
}
?>