<?php
class Employee
{
    private $eid, $ename;
    //
    public function __construct($eid,$ename)
    {
        $this->eid = $eid;
        $this->ename = $ename;
    }
    //eid
    public function geteid()
    {
        return $this->eid;
    }
    public function seteid($value)
    {
        $this->eid = $value;
    }
    //ename
    public function getename()
    {
        return $this->ename;
    }
    public function setename($value)
    {
        $this->ename = $value;
    }
}
$obj1 = new Employee('102','Vimal');
echo "<br> object 1 is <br>";
print_r($obj1);

$obj2 = new Employee('106','Dhaval');
echo "<br> object 2 is <br>";
print_r($obj2);

$obj1 = clone $obj2;
echo "<br> after set obj1 = obj2 <br>";

echo "<br> object 1 is <br>";
print_r($obj1);

echo "<br> object 2 is <br>";
print_r($obj2);

$obj2->setename('Chetan');
echo "<br> After set ename in object 2 <br>";
print_r($obj1);
echo "<br>";
print_r($obj2);

?>