<?php

/*
    fopen=The fopen() function opens a file.
    fgets=The fgets() function returns a line from an open file.
    fgetcsv=The fgetcsv() function parses a line from an open file, checking for CSV fields.

    FOPEN & GETS
$file = fopen("testfile.txt","r");
echo fgets($file);
fclose($file);

    FGETCSV
$file = fopen("contacts.csv","r");
print_r(fgetcsv($file));
fclose($file);

*/

$num=array('1', '2', '3');
echo $num[2];
print_r(key($num));
?>
