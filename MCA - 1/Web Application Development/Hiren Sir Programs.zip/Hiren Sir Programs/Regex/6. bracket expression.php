<?php
$string = 'The product code is JTK-4702';
$ans1 = preg_match('/JTK[[:punct:]]/',$string); // returns 1
echo "<br> Answer : $ans1";
$ans2 = preg_match('/JT[[:upper:]]/',$string); // returns 1
echo "<br> Answer : $ans2";
$ans3 = preg_match('/JTK[[:digit:]]/',$string); // returns 0
echo "<br> Answer : $ans3";
$ans4 = preg_match('/JTK-[[:digit:]]/',$string); // returns 1
echo "<br> Answer : $ans4";
?>
