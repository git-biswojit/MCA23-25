<?php
$pattern = '/hiren/';
$author = 'HIREN JOSHI';
//preg_match
$ans = preg_match($pattern,$author);  // $ans is 0
echo "<br> $ans";
//case in-sensitive
$pattern = '/hiren/i';
$author = 'HIREN JOSHI';
//preg_match
$ans = preg_match($pattern,$author);  // $ans is 1
echo "<br> $ans";
?>
