<?php
$pattern1 = '/^(?=.*[[:digit:]])[[:alnum:]]{6}$/';
$ans1 = preg_match($pattern1,'Paresh');
echo "<br> Ans1 : $ans1";
$ans2 = preg_match($pattern1,'Pares8');
echo "<br> Ans2 : $ans2";
//negative lookahead assertion
$pattern2 = '/^(?!3[2-9])[0-3][[:digit:]]$/';
// $pattern2 = '/^([0-2][[:digit:]])|(3[0-1])$/';  
$ans3 = preg_match($pattern2,'32');
echo "<br> Ans3 : $ans3";
$ans4 = preg_match($pattern2,'31');
echo "<br> Ans4 : $ans4";
//password complexity
$pwd = '/^(?=.*[[:digit:]])(?=.*[[:punct:]])[[:print:]]{6,}$/';
// ^  represent from the start of the pattern
//    (?=.*[[:digit:]]) represent that the assertion must contain atleast one digit 
//    (?=.*[[:punct:]]) represent that the assertion must containt atleast one punctuation character 
//    [[:print:]]{6,} represent that the pattern must have  6 or more printable characters
//	  $ represent from the end of the pattern
$pass1 = 'super3man';
$p1 = preg_match($pwd, $pass1);
echo "<br> pass1 : $p1";
$pass2 = 'super2m@n';
$p2 = preg_match($pwd, $pass2);
echo "<br> pass2 : $p2";
?>