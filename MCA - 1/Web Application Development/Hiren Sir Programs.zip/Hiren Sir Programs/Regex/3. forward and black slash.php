<?php
// backslash
$string = 'This is backslash \ which is used as escape character in regex';
$ans = preg_match('/\\\\/',$string);
echo $ans;
if($ans === 1)
{
	echo "<h1> Pattern is  matched";
}
else
{
	echo "<h1> Pattern is not matched";
}
// forward slash
$string = 'This is forwardslash / which is used in regex';
$ans = preg_match('/\//',$string);
echo $ans;
?>