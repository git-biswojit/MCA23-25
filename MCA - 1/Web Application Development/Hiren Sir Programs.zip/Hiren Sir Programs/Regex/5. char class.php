<?php
$string = 'The product code is JTK-4702';
$ans1 = preg_match('/JT[JKL]/',$string); // returns 1
echo "<br> Answer : $ans1";  
$ans2 = preg_match('/JTK-[1234]/',$string);  // returns 1
echo "<br> Answer : $ans2"; 
$ans3 = preg_match('/JTK-[123]/',$string); // returns 0
echo "<br> Answer : $ans3";
$ans4 = preg_match('/JT[^JKL]/',$string);  // returns 0
echo "<br> Answer : $ans4";
$ans5 = preg_match('/JTK[^^]/',$string);  // returns 1
echo "<br> Answer : $ans5";
$ans6 = preg_match('/JTK-[1-4]/',$string); // returns 1
echo "<br> Answer : $ans6";
$ans7 = preg_match('/JTK[*-_]/',$string);  // returns 1
echo "<br> Answer : $ans7";
?>