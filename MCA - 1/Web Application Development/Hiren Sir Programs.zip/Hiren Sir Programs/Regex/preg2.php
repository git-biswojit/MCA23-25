<?php
$string = 'JTK-4702';
$ans = preg_match('/JT./',$string);
echo "<br> answer is $ans";
if($ans)
{
    echo "<br> pattern is matched";
}
else
{
    echo "<br> pattern is not matched";
}
$a = 'The product code is JTK-4702';
$p = '/JTK-[1245]/';
$r = preg_match($p,$a);
if($r)
{
    echo "<br> Pattern is matched";
}
else
{
    echo "<br> pattern is not matched";
}

?>