<?php
$pattern = '/hiren/i';
$author = 'HIREN JOSHI';
//preg_match
$ans = preg_match($pattern,$author);
if($ans) 
{
	echo "<h1> Pattern hiren is matched";
}
else
{
	echo "<h1> pattern hiren is not matched";
}
?>
