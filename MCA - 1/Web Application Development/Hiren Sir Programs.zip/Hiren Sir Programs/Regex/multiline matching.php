<?php
$string = 'Ray Harris\nAuthor';
$p1 = preg_match('/Harris/',$string);
echo "<br> p1 : $p1";
$p2 = preg_match('/Harris$/',$string);
echo "<br> p2 : $p2";
$p3 = preg_match('/Harris$/m',$string);
echo "<br> p3 : $p3";
?>