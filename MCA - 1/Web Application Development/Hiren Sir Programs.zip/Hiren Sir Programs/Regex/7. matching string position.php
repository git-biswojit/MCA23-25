<?php
$string = 'The product code is JTK-4702';
$ans1 = preg_match('/^The/',$string); //returns 1
echo "<br> Answer1 : $ans1";
$ans2 = preg_match('/4702$/',$string); //returns 1
echo "<br> Answer2 : $ans2";
$ans3 = preg_match('/code/',$string); //returns 1
echo "<br> Answer3 : $ans3";
$ans4 = preg_match('/^The product code is JTK-4702$/',$string); //returns 1
echo "<br> Answer4 : $ans4";
$ans5 = preg_match('/JTK\b/',$string); //returns 1
echo "<br> Answer5 : $ans5";
$ans6 = preg_match('/rod\B/',$string); //returns 1
echo "<br> Answer6 : $ans6";
?>