<?php
$pattern = '/\//';
$string = 'This is MCA1 2022 batch';
$ans = preg_match($pattern,$string);
if($ans)
{
    echo "<br> Pattern is matched";
}
else
{
    echo "<br> Pattern is not matched";
}
?>