<?php
$string = 'The product code is JTK-4702';
$ans1 = preg_match('/JT[^JKL]/',$string); 
echo "<br> Answer : $ans1";
$ans2 = preg_match('/JTK[^^]/',$string);
echo "<br> Answer : $ans2";
$ans3 = preg_match('/JTK-[1-5]/',$string);
echo "<br> Answer : $ans3";
$ans4 = preg_match('/JTK[*-_]/',$string);
echo "<br> Answer : $ans4";
?>
