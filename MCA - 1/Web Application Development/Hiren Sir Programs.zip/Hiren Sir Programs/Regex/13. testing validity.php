<?php
//phone in 999-999-9999 format
$phone = '/^\d{3}-\d{3}-\d{4}$/';
$phone1 = '/^[[:digit:]]{3}-[[:digit:]]{3}-[[:digit:]]{4}$/';
$p1 ='559-237-8024';
$ans1 = preg_match($phone,$p1);
echo "<br> $ans1";
$ans11 = preg_match($phone1,$p1);
echo "<br> Ans11 : $ans11";
// Credit Card in 9999-9999-9999-9999-999
$creditcard = '/^\d{4}(-\d{4}){3}$/';
$card = '1234-5678-9012-3456';
$cardmatch = preg_match($creditcard,$card);
echo "<br> Card Match is : $cardmatch";
//Code in 99999 or 99999-9999
$code = '/^\d{5}(-\d{4}) ?$/';
$zip1 = '12345';
$zipm1 = preg_match($code,$zip1);
echo "<br> Zip1 $zip1 is matched";
$zip2 = '12345-6789';
$zipm2 = preg_match($code,$zip2);
echo "<br> Zip2 $zip2 is matched";
//date in format dd/mm/yyyy
$date = '/^(0?[1-9]|[12][[:digit:]]|[3][01])\/(0?[1-9]|1[012])\/[[:digit:]]{4}$/';
$bday = '12/7/1985';
$bdmatch = preg_match($date, $bday);
echo "<br> Birthday : $bdmatch";
?>