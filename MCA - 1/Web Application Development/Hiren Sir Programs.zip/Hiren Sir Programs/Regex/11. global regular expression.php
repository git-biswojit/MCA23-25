<?php
$string = 'JTK-4702 JTK-1379';
$pattern = '/JTK-[[:digit:]]{4}/';
$count = preg_match_all($pattern,$string,$matches);
foreach($matches[0] as $match)
{
	echo "<br> $match";
}
?>