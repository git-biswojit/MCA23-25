<?php
$items = 'JTK-4702 JTM-3795 JTM-1234 JTK-9876';
//$pattern = '/[, ]+(and [ ]*)?/';
$pattern = '/[, ]/';
$items = preg_split($pattern, $items);
foreach($items as $item)
{
	echo "<br> $item";
}
?>