<?php
$items = 'JTK-4702 JTM-3618';
$items = preg_replace('/JT[KM]/','PCode',$items);
echo $items;
?>