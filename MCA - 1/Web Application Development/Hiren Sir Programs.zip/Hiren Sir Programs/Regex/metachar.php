<?php
$string = 'The product code is JTK-4702';
$p1 ='/JT./';
$ans1 = preg_match($p1,$string);
echo "<br> Ans1: $ans1";
$p2 = '/JT\d/';
$ans2 = preg_match($p2,$string);
echo "<br> Ans2 : $ans2";
$p3 = '/JTK-/';
$ans3 = preg_match($p3,$string);
echo "<br> Ans2 : $ans3";

?>