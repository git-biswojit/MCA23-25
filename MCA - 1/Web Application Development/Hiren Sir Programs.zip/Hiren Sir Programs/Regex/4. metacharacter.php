<?php
$string = 'The product code is JTK-4702';
$ans1 = preg_match('/JT./',$string);
echo "<br> Answer : $ans1";
$ans2 = preg_match('/JT\d/',$string);
echo "<br> Answer : $ans2";
$ans3 = preg_match('/JTK-\d/',$string);
echo "<br> Answer : $ans3";
?>