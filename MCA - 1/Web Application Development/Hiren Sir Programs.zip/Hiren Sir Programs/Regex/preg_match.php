<?php
$author = 'Hiren Joshi';
$editor = 'Rajesh Joshi';
$pattern = '/Hiren/';
$ans = preg_match($pattern,$editor);
echo $ans;
if($ans === 1)
{
	echo "<br> Pattern is matched";
}
else if ($ans === 0)
{
	echo "<br> Pattern is not matched";
}
else
{
	echo "<br> Error";
}
// case -sensivity
$pattern1 = '/hiren/i';
$ans1 = preg_match($pattern1,$author);
echo "<br> Answer1 : $ans1";
?>