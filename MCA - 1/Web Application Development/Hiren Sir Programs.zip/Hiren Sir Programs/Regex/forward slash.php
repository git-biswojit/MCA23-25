<?php
$string = 'This is forwardslash / which is used in regex';
$ans = preg_match('/\//',$string);
echo $ans;
?>