<?php
$string = 'The product code is JTK-4702';
$string1 = 'Raj Rajeshwar';
$ans1 = preg_match('/^(Raj)|(Kaj)/',$string1); 
echo "<br> Answer1 : $ans1";
$ans2 = preg_match('/^(\w\w\w) \1/',$string1);  // numbered subpattern
echo "<br> Answer2 : $ans2";
$ans3 = preg_match('/^(The)|(That)/',$string); 
echo "<br> Answer3 : $ans3";
$ans4 = preg_match('/(rod\B)|(That)/',$string); 
echo "<br> Answer4 : $ans4";
// matching ode 
$pattern = '/(?:ode)/';
$ans5 = preg_match($pattern,$string);  //returns  1
if($ans5 === 1)
{
		echo "<br> $pattern is matched with $string";
}
else if($ans5 === 0)
{
		echo "<br> $pattern is not matched with $string";
}
else
{
		echo "<br> Error";
}
?>