<?php
$phone = '123-456-7890';
$phonepattern = '/^\d{3}-\d{3}-\d{4}$/';
$matchphonepattern = preg_match($phonepattern,$phone);
if($matchphonepattern === 1)
{
		echo "<br> Phone $phone is matched";
}
$fax = '(123) 456-7890';
$faxpattern = '/^\(\d{3}\) \d{3}-\d{4}$/';
$matchfaxpattern = preg_match($faxpattern,$fax);
if($matchfaxpattern === 1)
{
		echo "<br> Fax $fax is matched";
}
// phone or fax
$phoneorfax = '/^(\(\d{3}\) |(\d{3}-) ?)\d{3}-\d{4}$/';
//$patttern1 = '/^\d{6}$/';
$pmatch = preg_match($phoneorfax, $phone);
if($pmatch === 1)
{
	echo "<br> Phone is matched with phone or fax";
}
$fmatch = preg_match($phoneorfax, $fax);
if($fmatch === 1)
{
	echo "<br> Fax is matched with phone or fax";
}
?>