<?php
$string = 'JTK-1234 JTK-4567 JTK-7890 JTK-1456';
$pattern = '/JTK-\d{4}/';
$ans = preg_match($pattern,$string);
echo "<br> ans is $ans";
$resutl = preg_match_all($pattern,$string,$matches);
print_r($matches);
echo "<br>";
foreach($matches[0] as $match)
{
    echo "$match <br>";
}
?>