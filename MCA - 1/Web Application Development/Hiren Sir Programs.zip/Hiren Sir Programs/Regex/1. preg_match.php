<?php
$pattern = '/Hiren/'; 
$author = 'Hiren Joshi';
$editor = 'Hardik Joshi';
//preg_match
$ans = preg_match($pattern,$author);
echo $ans;
if($ans === False)
{
	echo "<br> There is error in pattern";
	
}
else if($ans === 1)
{
	echo "<br> pattern $pattern matched with author $author";
}
else
{
	echo "<br> pattern $pattern is not matched with author $author";
}

//editor check
$result = preg_match($pattern,$editor);
if($result === 1)
{
	echo "<br> pattern $pattern is matched with editor $editor";
}
else if($result === 0)
{
	echo "<br> pattern $pattern is not matched with editor $editor";
}
else
{
	echo "<br> There is an error";
}
?>
