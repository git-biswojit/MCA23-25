<?php
$string = 'JTK-4702 JTK-3795';
$pattern = '/JTK-[[:digit:]]{4}/';
$count = preg_match_all($pattern,$string,$matches);
foreach($matches[0] as $match)
{
	echo '<div>'.$match.'</div>';
}
// Delete 
echo "<br> Try <br> ";
print_r($matches);

foreach($matches as $k => $v)
{
	foreach($v as $k1 => $v1)
	{
		echo "<br> $v1";
	}
}
?>