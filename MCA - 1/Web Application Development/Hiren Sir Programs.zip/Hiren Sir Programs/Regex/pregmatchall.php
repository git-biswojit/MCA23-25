<?php
$string = 'JTK-4532 JTK-567 JTK-8901 JTK-453 JTK-3781';
$pattern = '/JTK-[[:digit:]]{4}/';
$count = preg_match_all($pattern,$string,$matches);
echo "<br> Total Matches : $count";
print_r($matches);
foreach($matches[0] as $m)
{
	echo "<br> $m";
}

?>