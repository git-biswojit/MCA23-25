<?php
$string = 'This is forward / slash';
$pattern = '/\//';
$ans = preg_match($pattern,$string);
echo "<br> $ans";
// backslash
$back = 'Backslash \ is a  escape character';
$bpattern = '/\\\\/';
$ans2 = preg_match($bpattern,$back);
echo "<br> Ans2: $ans2";
?>