<?php
$cwd = getcwd();
$sep = DIRECTORY_SEPARATOR;
$filename = 'product.txt';
$old = $cwd.$sep.$filename;
$new = 'New product.txt';
$success = copy($old,$new);
if ($success)
{
    echo "<br> File copied successfully";
}
else
{
    echo "<br> File is not copied successfully ";
}
?>