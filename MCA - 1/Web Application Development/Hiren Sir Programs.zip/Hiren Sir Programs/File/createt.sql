create table stud
(sid int ,
sname varchar(20),
constraint pk_id  primary key(sid));