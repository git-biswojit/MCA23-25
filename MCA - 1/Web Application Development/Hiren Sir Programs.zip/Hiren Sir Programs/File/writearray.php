<?php
$cwd = getcwd();
$sep = DIRECTORY_SEPARATOR;
$filename = 'city.txt';
$file = $cwd.$sep.$filename;
echo "<br> file is $file";
$names = array('Bhavnagar','Viramgam','Veraval');
$cities = implode("\n",$names);
echo "<br>";
print_r($cities);
//foreach($cities as $city)
//{}
file_put_contents($file,$cities)

?>
