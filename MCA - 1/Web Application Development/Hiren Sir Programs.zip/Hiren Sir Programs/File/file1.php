<?php
$path = "C:\\xampp\htdocs\File";
$sep = DIRECTORY_SEPARATOR;
$file = 'mca.txt';
$x = $path.$sep.$file;
echo "<br> file is $x";
$f1 = is_file($x);
if ($f1)
{
    echo "<br> file is exists";
}
else
{ 
    echo "<br> file does not exists";
}
//
$path = "C:\\xampp\htdocs";
$sep = DIRECTORY_SEPARATOR;
$file = 'File';
$x = $path.$sep.$file;
echo "<br> directory is $x";
$f1 = file_exists($x);
if ($f1)
{
    echo "<br> directory is exists";
}
else
{ 
    echo "<br> directory does not exists";
}

?>