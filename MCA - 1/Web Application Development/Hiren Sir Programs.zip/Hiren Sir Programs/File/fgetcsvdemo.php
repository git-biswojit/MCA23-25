<?php
$cwd = getcwd();
echo "<br> cwd is $cwd";
$sep = DIRECTORY_SEPARATOR;

/*
$products = array(array('p1','AMD RYZEN',60000),
                    array('p2','HP Vectus',62000));
*/
$filename = 'product.txt';
$path = $cwd.$sep.$filename;
echo "<br> path is $path";
$file = fopen($path,'rb');
echo fgetcsv($file);
fclose($file);

?>