<?php
$cwd = getcwd();
$sep = DIRECTORY_SEPARATOR;
$path = 'mca.txt';
$file = $cwd.$sep.$path;
echo "<br> File is $file";
echo "<br> read file <br>";
file_put_contents($file,'Bhavnagar');
//readfile($file);
$a = file($file);
print_r($a);
?>