<?php
$cwd = getcwd();
echo "<br> $cwd";
$sep = DIRECTORY_SEPARATOR;
$path = $cwd.$sep;
echo "<br> $path";
$tmp = $_FILES['file1']['tmp_name'];
echo "<br> Temporary file is $tmp";
$new = $_FILES['file1']['name'];
$success = move_uploaded_file($tmp,$new);
if ($success)
{
    echo "<br> File uploaded successsfully";
}
?>