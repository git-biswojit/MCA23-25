<?php
$cwd = getcwd();
$sep = DIRECTORY_SEPARATOR;
$filename = 'city.txt';
$path = $cwd.$sep.$filename;
echo "<br> file is $path";
$file = fopen($path,'rb');
//$l = fread($file,15);
//echo "<br> $l";
echo "<br>";
while(!feof($file))
{
    echo fgets($file);
    echo "<br>";
}
fclose($file);
?>