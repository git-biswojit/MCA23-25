<?php
$cwd = getcwd();
$sep = DIRECTORY_SEPARATOR;
$new = 'New product.txt';
if (file_exists($new))
{
    $success = unlink($new);
}
if ($success)
{
    echo "<br> File deleted successfully";
}
else
{
    echo "<br> File is not deleted successfully ";
}
?>