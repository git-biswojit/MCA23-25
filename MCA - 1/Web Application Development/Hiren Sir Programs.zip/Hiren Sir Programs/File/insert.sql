insert into stud values(8,'Meet');
insert into stud values(26,'Dhruvil');
insert into stud values(16,'Harshit');

