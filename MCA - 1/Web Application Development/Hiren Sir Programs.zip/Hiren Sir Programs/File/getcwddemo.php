<?php
$cwd = getcwd();
echo "<br> current directory is : $cwd";
?>