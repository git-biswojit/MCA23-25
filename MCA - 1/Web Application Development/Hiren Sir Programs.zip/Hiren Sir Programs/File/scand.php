<?php
$path = getcwd();
$ans = scandir($path);
$files = array();
foreach($ans as $a)
{
   if(is_file($a))
   {
    $files[] = $a;
    //echo "$a <br>";
   } 
}
foreach($files as $a)
{
    echo "$a <br>";
}
/*
if (is_file($path))
{

}
//print_r($ans);
foreach($ans as $a)
{
    echo $a."<br>";
}
*/
?>