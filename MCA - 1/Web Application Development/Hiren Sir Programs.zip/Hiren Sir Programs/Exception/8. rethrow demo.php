<?php
class customException extends Exception
{
	public function errorMessage()
	{
		// errorMessage
		$errormsg = $this->getMessage(). ' is not a valid E-Mail address';
		return $errormsg;
	}
}
$email = "someone@example.com";
try
{
	try
	{
		//check for "example" in email address
		if(strpos($email,"example") !== FALSE)
		{
			//throw exception if email is not valid
			throw new Exception($email);
		}
	}
	catch(Exception $e)
	{
		//re-throw exception
		throw new customException($email);
	}
}
catch (customException $e)
{
	// display custome message
	echo $e->errorMessage();
}
?>