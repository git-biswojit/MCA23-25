<?php
//create  custom exception class
class customException extends Exception
{ 
	public function errorMessage()
	{
		$errormsg = "<br> Error on line ".$this->getLine().' in <br>File: '.$this->getFile().
		"Error Message <b>".$this->getMessage()."</b><br>Please enter valid inputs";
		return $errormsg;
	}
}
// inputs
$p = 1000;
$r = 0;
$n = 2;
// function
function simple($p,$r,$n)
{
	
		$si = ($p*$r*$n)/100;
		return $si;
}
try
{
	try
	{
		if($p <= 0 )
		{
			throw new Exception("Please enter valid principal");
		}
		if ($r <= 0)
		{
			throw new Exception("Please enter valid rate");
		}
		if($n <= 0)
		{
			throw new Exception("Please enter valid duration");
		}
		if($p <= 0 || $r <= 0 || $n <= 0)
		{
				throw new customException();
		}
	}
	catch(Exception $e)
	{
		echo "<br> Exception :".$e->getMessage();
		throw new customException();
	}
}
catch (customException $e)
	{
		echo $e->errorMessage();
	}
$ans = simple($p,$r,$n);
echo "<br> Simple Interest : $ans";
?>