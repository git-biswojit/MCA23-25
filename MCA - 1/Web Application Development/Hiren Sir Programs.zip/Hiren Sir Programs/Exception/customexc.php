<?php
class customexception extends Exception
{
    public function mymessage()
    {
        $message = "<br> Error in file ".$this->getFile(). 
        "<br> Error at Line ".$this->getLine(). 
        "<br> Error Message ". $this->getMessage();
        return $message;
    }
}
function simple($p,$r,$n)
{
    if ($p <= 0 || $r <= 0 || $n <= 0)
    {
        throw new customexception();
    }
    $si = ($p * $r * $n)/100;
    echo "<br> Simple Interest is $si";
}
$p = 1000;
$r = 0;
$n = 2;
try
{
    $ans = simple($p,$r,$n);
}
catch (customexception $e)
{
    echo $e->mymessage();
}
catch (Exception $e)
{
    echo $e->getMessage();
}
?>