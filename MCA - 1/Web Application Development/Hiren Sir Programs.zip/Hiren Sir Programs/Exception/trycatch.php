<?php
function simple($p,$r,$n)
{
    if ($p <= 0 || $r <= 0 || $n <= 0)
    {
        throw new Exception('Enter valid values');
    }
    $si = ($p * $r * $n)/100;
    echo "<br> Simple Interest is $si";
}
$p = 1000;
$r = 0;
$n = 2;
try
{
    $ans = simple($p,$r,$n);
}
catch (Exception $e)
{
    echo $e->getMessage();
}
?>