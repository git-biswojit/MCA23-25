<?php
function simple($p,$r,$n)
{
    if ($p <= 0 AND $r <= 0 AND $n <= 0)
    {
        throw new Exception('Enter valid values');
    }
    if ($p <= 0)
    {
        throw new Exception('Enter valid principle amount');
    }
    if ($r <= 0)
    {
        throw new Exception('Enter valid rate');
    }
    if ($n <= 0)
    {
        throw new Exception('Enter valid duration');
    }
    $si = ($p * $r * $n)/100;
    echo "<br> Simple Interest is $si";
}
$p = 1000;
$r = 0;
$n = 2;
try
{
    $ans = simple($p,$r,$n);
}
catch (Exception $e)
{
    echo $e->getMessage();
}
?>