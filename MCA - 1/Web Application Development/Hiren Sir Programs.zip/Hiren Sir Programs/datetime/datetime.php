<?php
$dt = new DateTime();
print_r($dt);
echo "<br>";
echo $dt->format('d/m/y');


$invoicedate = new DateTime('2014-03-23 14:30:18');
$due_date = clone $invoicedate;
echo "<dr> Invoice date is:".$invoicedate->format('M j Y g:i:s a');
$due_date->modify('+4 weeks');
echo "<br> Due Date (After 4 weeks of invoice date) is: ".$due_date->format('M j Y \a\t g:i:s a');

$a = new DateInterval('P1Y23D');
echo "<br>";
print_r($a);

echo "<br>";
$votingage = new DateInterval('P18Y');
$dob = new DateTime();
$dob->sub($votingage);
echo '<br> You can vote only if you were born on or before: '. $dob->format('j/n/Y');


?>