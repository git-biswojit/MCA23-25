<?php
$d= date('d/m/y h:i:s A');
echo "<br> date is $d";
$t = time();
echo "<br> time is $t";
$m = mktime(10,12,23,6,15,2018);
echo "<br> $m";
$date6 = strtotime('next Sunday') ;
$date6 = date('d/m/y',$date6);
echo "<br> $date6";

?>