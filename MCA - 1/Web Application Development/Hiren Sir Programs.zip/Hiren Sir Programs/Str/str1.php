<?php
$str = 'A   Today is Monday   Z  ';
echo "<br> The original string is $str";
$len = strlen($str);
echo "<br> The length of the string $str is $len";
// substr
$substr = substr($str,6);
echo "<br> The substring is $substr";
$mon = substr($str,2,-4);
echo "<br> $mon";
//strpos
$i = strrpos($str,'o'); 
echo "<br> Postion of o at $i";
$rep = str_replace('Monday','Tuesday',$str);
echo "<br> str is $str and <br> Replaced string is $rep";
$ltrim = trim($str);
echo "<br> after ltrim the length is $ltrim ";
$pad = str_pad($str,50,'*',STR_PAD_BOTH);
echo "<br> After padded with * the string is $pad";
$upper = 'this is upper case ';
$lc = strrev($upper);
echo "<br> upper : $upper <br> lower : $lc";
$a1 = 'MALAYALAM';
echo "<br> Original : $a1";
$reva1 = strrev($a1);
if ($a1 == $reva1)
{
    echo "<br> This is a palindrom word <br>";
}
$shuffle = str_shuffle($str);
echo "<br> original $str <br> shuffled $shuffle <br>";
$rep = str_repeat($a1,5);
echo "<br> $rep";

$email = 'abc@def.com, ghi@jkl.mno, opq@rst.uvw';

$exp = explode(',',$email);
print_r($exp);
foreach($exp as $e)
{
    echo $e . ' ';
}
$imp = implode('*',$exp);
echo "<br> $imp <br>";
$chr = ord('H');
echo "<br> $chr";
$ans = strcmp('Arun','Sapna');
echo "<br> $ans";
$i1 = 'image3';
$i2 = 'image10';
$ans1 = strcmp($i1,$i2);
echo "<br> $ans1";
$ans2 = strnatcmp($i1,$i2);
echo "<br> $ans2";

?>