<?php
$a = PHP_INT_MAX;
echo "<br> a is $a ";
$b = INF;
$c = 10 * $b;
echo "<br> c is $c";
if (is_infinite($c))
{
    echo "<br> c is infinite";
}
else
{
    echo "<br> c is not infinite";
}
//$d = 0;
//$e = 0;
//$f = ($d/$e);
//echo "<br> f is $f";
$n = -5;
$ans = abs($n);
echo "<br> $n after abs is $ans";
$n1 = 1551;
$ans = round($n1,-2);
echo "<br> $ans";
$f = floor(-1234.567);
echo "<br> $f";
$m = max(10,12,34,76,18);
echo "<br> maximum value is $m";
$s = sqrt(36);
echo "<br> square root of 36 is $s";
$r = mt_rand(1,10);
echo "<br> random value between 1 and 1o is $r ";
$val = 31;
$int = (int)$val;
echo "<br> Original $val :  after it becomes $int";
$miles = '31';
echo "<br> orginal $miles";
$i = (float)$miles;
echo "<br> after converting to int $i";
?>