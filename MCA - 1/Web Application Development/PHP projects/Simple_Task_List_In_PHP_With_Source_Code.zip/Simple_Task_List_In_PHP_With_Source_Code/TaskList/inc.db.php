<?php
    // File: inc.db.php

    const HOST = 'localhost';
    const USER = 'root';
    const PWD = '';
    const DB = 'project';

    const CONNECT_MYSQL = 'mysql:host=' . HOST . ';dbname=' . DB;
?>